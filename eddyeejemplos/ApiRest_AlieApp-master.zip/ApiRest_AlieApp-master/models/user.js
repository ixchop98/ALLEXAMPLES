'use strict'

function User(){
	this.id = null,
	this.nombre = null,
	this.apellido = null,
	this.password = null,
	this.correo = null,
	this.telefono = null,
	this.foto = null,
	this.genero = null,
	this.fechaNacimiento = null,
	this.fechaRegistro = null,
	this.direccion = null,
	this.username = null,
	this.estado = null,
	this.idRole = null
}



module.exports = User;