'use strict'

var cn = {
	user: "db_AlieApp",
	password: "SDnlbI",
	connectString: "localhost:1521/xe"
}

module.exports = cn;